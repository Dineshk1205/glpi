---
name: CVE Finding Report
about: CVE reporting for ingress-nginx
title: ''
labels: kind/bug
assignees:
    - strongjz
    - rikatz
---

<!-- if you found something that impacts directly ingress-nginx and
is not a public CVE yet, please reach out security@kubernetes.io" -->

<!-- What scanner and version reported the CVE? -->

<!-- What CVE was reported in the scanner findings? -->

<!-- What versions of the controller did you test with?  -->

<!-- Please provider other details that will help us determine the severity of the issue -->
