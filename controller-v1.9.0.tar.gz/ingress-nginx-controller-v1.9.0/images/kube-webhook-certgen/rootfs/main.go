package main

import (
	"github.com/jet/kube-webhook-certgen/cmd"
)

func main() {
	cmd.Execute()
}
