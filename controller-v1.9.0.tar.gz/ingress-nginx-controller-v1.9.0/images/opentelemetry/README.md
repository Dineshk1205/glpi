# OpenTelemetry library builder

**How to use this image:**
This image only contains the necessary files in /usr/local and /etc/nginx/opentelemetry to 
be copied to Ingress Controller deployment when OpenTelemetry is enabled
